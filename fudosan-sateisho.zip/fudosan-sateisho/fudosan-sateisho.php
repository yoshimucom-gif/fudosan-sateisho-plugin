<?php
/**
 * Plugin Name: 不動産 査定書作成受付
 * Description: 査定書の作成を受け付けるフォーム。物件情報とメールを受け取り、受付完了メールを自動返信＋管理者に通知。査定書は後日スタッフが作成して送付。ショートコード [fudosan_sateisho] をページに貼るだけ。
 * Version: 1.9.3
 * Author: (運営者)
 * License: GPLv2 or later
 * Text Domain: fudosan-sateisho
 *
 * ★法的注意: スタッフが作成する査定書は「参考価格の情報提供」であり、
 *   不動産鑑定士の「鑑定評価」ではない。免責文で明示すること。公開前に弁護士等の確認を推奨。
 */

if (!defined('ABSPATH')) exit; // 直接アクセス禁止

define('FSS_VER', '1.9.3');
define('FSS_OPT', 'fudosan_sateisho_options');

/**
 * 自動更新の置き場（update.json の URL）。
 * ミカタのサーバー/WPサイト上のフォルダに update.json と fudosan-sateisho.zip を
 * 置き、その update.json の URL をここに設定する。新バージョンを置くと WP管理画面に
 * 「更新可能」バッジが出て、ワンクリック更新できる（各サイトへの手動配布は不要）。
 * ※ 空なら自動更新は無効（手動アップロードでの運用は可能）。
 */
define('FSS_UPDATE_URL', 'https://raw.githubusercontent.com/yoshimucom-gif/fudosan-sateisho-plugin/main/update.json');

/* 更新チェッカー（URL未設定なら無効）
   ★is_admin() で囲まないこと。WordPressの自動更新は WP-Cron（管理画面外）で走るため、
     管理画面限定にすると「自動更新を有効化」をONにしても更新が入らない。 */
if (is_admin() || (defined('DOING_CRON') && DOING_CRON) || (defined('WP_CLI') && WP_CLI)) {
    require_once __DIR__ . '/includes/plugin-updater.php';
    new FSS_Sateisho_Updater(__FILE__, FSS_UPDATE_URL);
}

/* =========================================================================
 * 1. 有効化: リード保存テーブル作成
 * ======================================================================= */
register_activation_hook(__FILE__, 'fss_activate');
function fss_activate() {
    global $wpdb;
    $table = $wpdb->prefix . 'fudosan_sateisho_leads';
    $charset = $wpdb->get_charset_collate();
    // dbDeltaは「1カラム1行」でないと既存テーブルへのカラム追加を取りこぼす
    $sql = "CREATE TABLE $table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        created_at DATETIME NOT NULL,
        email VARCHAR(191) NOT NULL,
        ptype VARCHAR(20) NULL,
        address VARCHAR(255) NULL,
        details LONGTEXT NULL,
        purpose VARCHAR(50) NULL,
        marketing_opt_in TINYINT(1) DEFAULT 0,
        PRIMARY KEY  (id)
    ) $charset;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    fss_ensure_columns();
}

/* dbDeltaの取りこぼし対策: 不足カラムを明示的にALTERで追加（確実） */
function fss_ensure_columns() {
    global $wpdb;
    $t = $wpdb->prefix . 'fudosan_sateisho_leads';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) !== $t) return;
    $cols = $wpdb->get_col("SHOW COLUMNS FROM `$t`", 0);
    if (!is_array($cols)) return;
    $need = array(
        'address'      => 'VARCHAR(255) NULL',
        'details'      => 'LONGTEXT NULL',
        'purpose'      => 'VARCHAR(50) NULL',
    );
    foreach ($need as $c => $def) {
        if (!in_array($c, $cols, true)) {
            $wpdb->query("ALTER TABLE `$t` ADD COLUMN `$c` $def");
        }
    }
}

/* 自動更新でバージョンが上がったらテーブル定義を追従（新カラム追加等） */
add_action('plugins_loaded', 'fss_maybe_upgrade');
function fss_maybe_upgrade() {
    if (get_option('fss_db_ver') !== FSS_VER) {
        fss_activate();
        update_option('fss_db_ver', FSS_VER);
    }
}

/* =========================================================================
 * 2. 設定（APIキー・運営者情報）
 * ======================================================================= */
function fss_opt($key, $default = '') {
    $o = get_option(FSS_OPT, array());
    return isset($o[$key]) && $o[$key] !== '' ? $o[$key] : $default;
}

/* 公開前チェック。お客様に見える信頼性の材料が抜けたまま公開されるのを防ぐ */
add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) return;
    $miss = array();
    if (fss_opt('operator_name', '') === '')    $miss[] = '運営者名（会社名）';
    if (fss_opt('operator_contact', '') === '') $miss[] = '問い合わせ先';
    if (fss_opt('privacy_url', '') === '')      $miss[] = 'プライバシーポリシーURL';
    if (!$miss) return;
    echo '<div class="notice notice-warning"><p><strong>【査定書作成受付】公開前に未設定の項目があります：'
       . esc_html(implode(' / ', $miss)) . '</strong><br>'
       . 'これらはフォーム上でお客様に表示され、「どこの会社に自宅の情報を渡すのか」を判断する材料になります。'
       . '未設定のままだと信頼性が下がり、個人情報の利用目的の説明としても不十分です。'
       . '<a href="' . esc_url(admin_url('admin.php?page=fudosan-sateisho')) . '">設定画面</a>からご記入ください。</p></div>';
});

add_action('admin_menu', function () {
    // 専用のトップレベルメニュー（設定 と 受付一覧 をまとめる）
    add_menu_page('査定書作成受付', '査定書作成受付', 'manage_options', 'fudosan-sateisho', 'fss_settings_page', 'dashicons-media-document', 59);
    add_submenu_page('fudosan-sateisho', '設定', '設定', 'manage_options', 'fudosan-sateisho', 'fss_settings_page');
    add_submenu_page('fudosan-sateisho', '受付一覧', '受付一覧', 'manage_options', 'fudosan-sateisho-leads', 'fss_leads_page');
});

add_action('admin_init', function () {
    register_setting('fss_group', FSS_OPT, 'fss_sanitize_options');
});

function fss_sanitize_options($in) {
    $areas = array();
    if (!empty($in['areas']) && is_array($in['areas'])) {
        foreach ($in['areas'] as $a) { $a = sanitize_text_field($a); if ($a !== '') $areas[] = $a; }
    }
    return array(
        'site_name'        => sanitize_text_field($in['site_name'] ?? '査定書作成受付'),
        'operator_name'    => sanitize_text_field($in['operator_name'] ?? ''),
        'operator_contact' => sanitize_text_field($in['operator_contact'] ?? ''),
        'operator_address' => sanitize_text_field($in['operator_address'] ?? ''),
        'from_email'       => sanitize_email($in['from_email'] ?? get_option('admin_email')),
        'notify_email'     => sanitize_email($in['notify_email'] ?? ''),
        'privacy_url'      => esc_url_raw($in['privacy_url'] ?? ''),
        'terms_url'        => esc_url_raw($in['terms_url'] ?? ''),
        // 表示項目（未送信=チェック外れ=非表示）
        'show_purpose'     => !empty($in['show_purpose']) ? '1' : '',
        'show_marketing'   => !empty($in['show_marketing']) ? '1' : '',
        // 対象エリア（空=全国）
        // 自動返信メール
        'mail_subject'     => sanitize_text_field($in['mail_subject'] ?? ''),
        'mail_body'        => sanitize_textarea_field($in['mail_body'] ?? ''),
        // 装飾（色）
        'color_brand'      => sanitize_hex_color($in['color_brand'] ?? '')    ?: '#1f6feb',
        'color_btn_text'   => sanitize_hex_color($in['color_btn_text'] ?? '') ?: '#ffffff',
        'color_title'      => sanitize_hex_color($in['color_title'] ?? '')    ?: '#1f6feb',
        'color_badge'      => sanitize_hex_color($in['color_badge'] ?? '')    ?: '#ff5a36',
    );
}

/* 利用目的の選択肢（リードの質を測る重要データ） */
function fss_purposes() {
    return array(
        '売却を検討している',
        '相続した・相続する予定',
        '離婚による財産分与',
        '住み替えを検討している',
        '資産価値を把握したい',
        'その他',
    );
}

/* セレクトの選択肢 */
function fss_opt_list($key) {
    switch ($key) {
        case 'direction':    return array('北','北東','東','南東','南','南西','西','北西');
        case 'land_right':   return array('所有権','借地権');
        case 'structure':    return array('木造','軽量鉄骨造','重量鉄骨造','鉄筋コンクリート造(RC)','鉄骨鉄筋コンクリート造(SRC)','その他');
        case 'road_contact': return array('一方','角地','二方','三方','四方');
        case 'road_type':    return array('公道','私道');
        case 'layout':       return array('1R','1K','1DK','1LDK','2K','2DK','2LDK','3K','3DK','3LDK','4LDK以上');
    }
    return array();
}

/* 物件種別ごとの入力項目（マンション/戸建て/土地で異なる）。
   type: text|number|select|textarea|check、req: 必須、opts: fss_opt_list のキー */
function fss_property_fields() {
    return array(
        'mansion' => array(
            array('key'=>'mansion_name',  'label'=>'マンション名', 'type'=>'text',   'req'=>true,  'ph'=>'例：〇〇マンション'),
            array('key'=>'floor',         'label'=>'階数',        'type'=>'number', 'req'=>false, 'ph'=>'例：5'),
            array('key'=>'room_no',       'label'=>'部屋番号',    'type'=>'text',   'req'=>false, 'ph'=>'例：503'),
            array('key'=>'exclusive_area','label'=>'専有面積（㎡）','type'=>'number','req'=>true,  'ph'=>'例：70'),
            array('key'=>'direction',     'label'=>'方角',        'type'=>'select', 'req'=>false, 'opts'=>'direction'),
            array('key'=>'corner',        'label'=>'角部屋',      'type'=>'check',  'req'=>false, 'chk'=>'角部屋である'),
            array('key'=>'build_year',    'label'=>'築年（西暦）', 'type'=>'number', 'req'=>true,  'ph'=>'例：2015'),
            array('key'=>'layout',        'label'=>'間取り',      'type'=>'select', 'req'=>false, 'opts'=>'layout'),
            array('key'=>'reform',        'label'=>'リフォーム履歴','type'=>'textarea','req'=>false,'ph'=>'例：2020年に水回りをリフォーム'),
        ),
        'house' => array(
            array('key'=>'floors',        'label'=>'階建',        'type'=>'number', 'req'=>false, 'ph'=>'例：2'),
            array('key'=>'build_year',    'label'=>'築年（西暦）', 'type'=>'number', 'req'=>true,  'ph'=>'例：2010'),
            array('key'=>'land_right',    'label'=>'土地権利',    'type'=>'select', 'req'=>true,  'opts'=>'land_right'),
            array('key'=>'land_area',     'label'=>'土地面積（㎡）','type'=>'number','req'=>true,  'ph'=>'例：120'),
            array('key'=>'building_area', 'label'=>'建物面積（㎡）','type'=>'number','req'=>true,  'ph'=>'例：95'),
            array('key'=>'structure',     'label'=>'建築構造',    'type'=>'select', 'req'=>true,  'opts'=>'structure'),
            array('key'=>'road_contact',  'label'=>'接道状況',    'type'=>'select', 'req'=>false, 'opts'=>'road_contact'),
            array('key'=>'road_width',    'label'=>'前面道路幅員（m）','type'=>'number','req'=>false,'ph'=>'例：4'),
            array('key'=>'road_direction','label'=>'接道方向',    'type'=>'select', 'req'=>false, 'opts'=>'direction'),
            array('key'=>'road_type',     'label'=>'道路種別',    'type'=>'select', 'req'=>false, 'opts'=>'road_type'),
            array('key'=>'road_frontage', 'label'=>'接道間口（m）','type'=>'number','req'=>false, 'ph'=>'例：5'),
            array('key'=>'layout',        'label'=>'間取り',      'type'=>'select', 'req'=>false, 'opts'=>'layout'),
            array('key'=>'reform',        'label'=>'リフォーム履歴','type'=>'textarea','req'=>false,'ph'=>'例：2020年に外壁塗装'),
        ),
        'land' => array(
            array('key'=>'land_area',     'label'=>'土地面積（㎡）','type'=>'number','req'=>true,  'ph'=>'例：150'),
            array('key'=>'land_right',    'label'=>'土地権利',    'type'=>'select', 'req'=>true,  'opts'=>'land_right'),
            array('key'=>'road_contact',  'label'=>'接道状況',    'type'=>'select', 'req'=>true,  'opts'=>'road_contact'),
            array('key'=>'road_width',    'label'=>'前面道路幅員（m）','type'=>'number','req'=>false,'ph'=>'例：4'),
            array('key'=>'road_direction','label'=>'接道方向',    'type'=>'select', 'req'=>false, 'opts'=>'direction'),
            array('key'=>'road_type',     'label'=>'道路種別',    'type'=>'select', 'req'=>false, 'opts'=>'road_type'),
            array('key'=>'road_frontage', 'label'=>'接道間口（m）','type'=>'number','req'=>false, 'ph'=>'例：8'),
        ),
    );
}

/* teaser で選べる項目（fields属性で指定）。req=必須扱い */

/* fields="ptype,pref,city" を検証済みの順序付きリストに */

/* #rrggbb → "r,g,b"（ブランド色を rgba() で薄く使うため） */
function fss_hex_to_rgb($hex) {
    $hex = ltrim((string)$hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    if (strlen($hex) !== 6 || !ctype_xdigit($hex)) return '31,111,235';
    return hexdec(substr($hex, 0, 2)) . ',' . hexdec(substr($hex, 2, 2)) . ',' . hexdec(substr($hex, 4, 2));
}

/* 表示項目の判定（未保存＝デフォルト表示、保存済みは値そのもの。空='非表示'を区別） */
function fss_show($key) {
    $o = get_option(FSS_OPT, array());
    if (!is_array($o) || !array_key_exists('show_' . $key, $o)) {
        // 未設定のときの既定。営業案内メールの希望欄だけ既定オフ（必要なサイトは管理画面でON）
        return $key !== 'marketing';
    }
    return $o['show_' . $key] === '1';
}

/* 対象エリアで都道府県を絞る（未設定なら全国）。数値文字列キーは整数化されるため非strict比較 */

/* 受付完了メールの初期本文（お客様へ・差し込みタグ付き） */
function fss_default_mail_body() {
    return "【{site_name}】査定書作成のお申し込みを受け付けました\n\n"
        . "この度はお申し込みいただきありがとうございます。\n"
        . "以下の内容で査定書の作成を受け付けました。\n\n"
        . "{property_details}\n\n"
        . "担当者が査定書を作成し、後日このメールアドレス宛にお送りします。\n"
        . "いましばらくお待ちください。\n\n"
        . "───────────────────────────────\n"
        . "【ご注意】\n"
        . "・作成する査定書は『参考価格の情報提供』であり、\n"
        . "  不動産鑑定士による『鑑定評価』ではありません。\n"
        . "・実際の売却価格・成約価格を保証するものではありません。\n"
        . "・当社は宅地建物取引業者ではなく、売買の媒介・代理は行いません。\n"
        . "───────────────────────────────\n\n"
        . "{operator_name}\n"
        . "お問い合わせ: {operator_contact}";
}

/* 管理者通知メールの本文（スタッフへ） */
function fss_admin_notify_body($ctx, $email) {
    $pd = array();
    $pd[] = "■ 物件種別 : {$ctx['ptype_label']}";
    if (!empty($ctx['address'])) $pd[] = "■ 物件住所 : {$ctx['address']}";
    if (!empty($ctx['purpose'])) $pd[] = "■ 利用目的 : {$ctx['purpose']}";
    if (!empty($ctx['details']))  $pd[] = $ctx['details'];
    return "査定書作成の受付が届きました。\n\n"
        . "■ お客様メール : {$email}\n"
        . implode("\n", $pd) . "\n"
        . "\n管理画面「査定書作成受付 → 受付一覧」からも確認できます。";
}

function fss_settings_page() {
    $o = get_option(FSS_OPT, array());
    $sel_areas = (isset($o['areas']) && is_array($o['areas'])) ? $o['areas'] : array();
    ?>
    <div class="wrap">
        <h1>査定書作成受付 設定</h1>
        <?php if (isset($_GET['testmail'])) {
            $tm_ok = ($_GET['testmail'] === '1');
            $tm_to = isset($_GET['to']) ? sanitize_email(wp_unslash($_GET['to'])) : '';
            echo '<div class="notice notice-' . ($tm_ok ? 'success' : 'error') . '"><p>' .
                ($tm_ok
                    ? 'テストメールを <strong>' . esc_html($tm_to) . '</strong> に送信しました。届かない場合は<strong>迷惑メールフォルダ</strong>も確認してください（届かない＝SPF/DKIM未設定の可能性大）。'
                    : 'テストメールの送信に失敗しました。WP Mail SMTP などの送信設定を確認してください。') .
                '</p></div>';
        } ?>
        <p>ページに <code>[fudosan_sateisho]</code> を貼ると査定書作成の受付フォームが表示されます。詳しい書き方は「<strong>使い方</strong>」タブへ。</p>
        <h2 class="nav-tab-wrapper" id="fss-tabs">
            <a href="#" class="nav-tab nav-tab-active" data-tab="basic">基本設定</a>
            <a href="#" class="nav-tab" data-tab="display">表示項目</a>
            <a href="#" class="nav-tab" data-tab="mail">自動返信メール</a>
            <a href="#" class="nav-tab" data-tab="style">デザイン</a>
            <a href="#" class="nav-tab" data-tab="usage">使い方</a>
        </h2>
        <form method="post" action="options.php">
            <?php settings_fields('fss_group'); ?>

            <div class="fss-tabpanel" data-tab="basic">
            <table class="form-table">
                <tr><th>サイト名</th><td><input type="text" name="<?php echo FSS_OPT; ?>[site_name]" value="<?php echo esc_attr(fss_opt('site_name', '査定書作成受付')); ?>" size="40">
                    <p class="description">メールの件名や差し込みに使われます。</p></td></tr>
                <tr><th>運営者名（会社名）</th><td><input type="text" name="<?php echo FSS_OPT; ?>[operator_name]" value="<?php echo esc_attr(fss_opt('operator_name')); ?>" size="40" placeholder="例：ミカタ株式会社">
                    <p class="description">フォームとメールに表示されます。<strong>お客様が「どこの会社に情報を渡すのか」を判断する材料</strong>なので、必ずご記入ください。</p></td></tr>
                <tr><th>所在地</th><td><input type="text" name="<?php echo FSS_OPT; ?>[operator_address]" value="<?php echo esc_attr(fss_opt('operator_address')); ?>" size="50" placeholder="例：岡山県岡山市北区○○1-2-3"></td></tr>
                <tr><th>問い合わせ先</th><td><input type="text" name="<?php echo FSS_OPT; ?>[operator_contact]" value="<?php echo esc_attr(fss_opt('operator_contact')); ?>" size="40" placeholder="例：086-000-0000 / info@example.com"></td></tr>
                <tr><th>送信元メール</th><td><input type="email" name="<?php echo FSS_OPT; ?>[from_email]" value="<?php echo esc_attr(fss_opt('from_email')); ?>" size="40" placeholder="<?php echo esc_attr(get_option('admin_email')); ?>">
                    <p class="description">お客様への受付完了メールの差出人。到達率のため WP Mail SMTP 等で SPF/DKIM を設定推奨。</p></td></tr>
                <tr><th>通知先メール（担当者）</th><td><input type="email" name="<?php echo FSS_OPT; ?>[notify_email]" value="<?php echo esc_attr(fss_opt('notify_email')); ?>" size="40">
                    <p class="description">受付が届いたら、このアドレスに通知します。空欄なら送信元メール（無ければ管理者アドレス）に通知します。</p></td></tr>
                <tr><th>プライバシーポリシーURL</th><td><input type="url" name="<?php echo FSS_OPT; ?>[privacy_url]" value="<?php echo esc_attr(fss_opt('privacy_url')); ?>" size="50"></td></tr>
                <tr><th>利用規約・免責URL</th><td><input type="url" name="<?php echo FSS_OPT; ?>[terms_url]" value="<?php echo esc_attr(fss_opt('terms_url')); ?>" size="50"></td></tr>
            </table>
            </div>

            <div class="fss-tabpanel" data-tab="display" style="display:none">
            <h3>フォームに表示する任意項目</h3>
            <table class="form-table"><tr><th>表示する項目</th><td>
                <label><input type="checkbox" name="<?php echo FSS_OPT; ?>[show_purpose]" value="1" <?php checked(fss_show('purpose')); ?>> 利用目的（売却検討・相続・離婚など）</label><br>
                <label><input type="checkbox" name="<?php echo FSS_OPT; ?>[show_marketing]" value="1" <?php checked(fss_show('marketing')); ?>> 「営業案内メールを希望」チェック欄（既定オフ）</label>
                <p class="description">
                    物件の入力項目（マンション／戸建て／土地ごとの項目）は、選ばれた種別に応じて自動で切り替わります。<br>
                    ※ 物件種別・物件住所・メール・同意チェックは常に表示されます。
                </p>
            </td></tr></table>
            </div>

            <div class="fss-tabpanel" data-tab="mail" style="display:none">
            <table class="form-table">
                <tr><th>件名</th><td>
                    <input type="text" name="<?php echo FSS_OPT; ?>[mail_subject]" value="<?php echo esc_attr(fss_opt('mail_subject')); ?>" size="60" placeholder="【{site_name}】査定結果のお知らせ">
                    <p class="description">空欄で初期件名（【サイト名】査定結果のお知らせ）。</p>
                </td></tr>
                <tr><th>本文</th><td>
                    <textarea name="<?php echo FSS_OPT; ?>[mail_body]" rows="22" style="width:100%;max-width:760px;font-family:monospace;font-size:13px"><?php echo esc_textarea(fss_opt('mail_body') ?: fss_default_mail_body()); ?></textarea>
                    <p class="description">
                        空欄にして保存すると初期文面に戻ります。使える差し込みタグ：<br>
                        <code>{site_name}</code> <code>{property_details}</code>（物件情報のまとまり） <code>{ptype}</code> <code>{address}</code> <code>{purpose}</code> <code>{details}</code> <code>{operator_name}</code> <code>{operator_contact}</code>
                    </p>
                    <p class="description" style="background:#f0f6fc;border-left:4px solid #2271b1;padding:10px 12px;margin-top:10px">
                        <strong>免責文（「鑑定評価ではない」旨）は、本文を自由に書き換えても自動で付きます（消せません）。</strong><br>
                        法令上、必ず必要なためです。本文には<strong>ご案内したい内容だけ</strong>をお書きください。
                        ご自身で同じ趣旨の文面を書かれた場合は、二重にならないよう自動付加を行いません。
                    </p>
                </td></tr>
                <tr><th>到達確認</th><td>
                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=fss_test_mail'), 'fss_test_mail')); ?>" class="button">テストメールを自分宛に送信</a>
                    <p class="description">
                        現在の件名・本文テンプレートでサンプルを送ります（保存してから押してください）。<br>
                        <strong>迷惑メールに入る場合</strong>は「WP Mail SMTP」等でSMTP送信にし、送信ドメインの <code>SPF</code> / <code>DKIM</code> / <code>DMARC</code> を設定してください。
                    </p>
                </td></tr>
            </table>
            </div>

            <div class="fss-tabpanel" data-tab="style" style="display:none">
            <h3>フォームの色</h3>
            <p class="description">保存すると、標準・compact・card・teaser すべてのフォームに反映されます。</p>
            <table class="form-table">
                <tr><th>ブランドカラー</th><td>
                    <input type="color" name="<?php echo FSS_OPT; ?>[color_brand]" value="<?php echo esc_attr(fss_opt('color_brand', '#1f6feb')); ?>">
                    <p class="description">ボタンの背景、査定価格の文字、入力済みチェック（✓）、次の入力欄のハイライトに使われます。</p>
                </td></tr>
                <tr><th>ボタンの文字色</th><td>
                    <input type="color" name="<?php echo FSS_OPT; ?>[color_btn_text]" value="<?php echo esc_attr(fss_opt('color_btn_text', '#ffffff')); ?>">
                </td></tr>
                <tr><th>見出しの色</th><td>
                    <input type="color" name="<?php echo FSS_OPT; ?>[color_title]" value="<?php echo esc_attr(fss_opt('color_title', '#1f6feb')); ?>">
                    <p class="description">teaser の見出し（例：60秒でかんたん入力！）の文字色。</p>
                </td></tr>
                <tr><th>「必須」バッジの色</th><td>
                    <input type="color" name="<?php echo FSS_OPT; ?>[color_badge]" value="<?php echo esc_attr(fss_opt('color_badge', '#ff5a36')); ?>">
                    <p class="description">未入力の項目に付くバッジ。入力すると「ブランドカラーの ✓」に変わります。</p>
                </td></tr>
            </table>
            <p class="description">初期値：ブランド <code>#1f6feb</code> ／ ボタン文字 <code>#ffffff</code> ／ 見出し <code>#1f6feb</code> ／ バッジ <code>#ff5a36</code></p>
            </div>

            <div class="fss-tabpanel" data-tab="usage" style="display:none">
            <h3>ショートコードの貼り方</h3>
            <p>受付フォームを出したい固定ページ・投稿・ウィジェット（カスタムHTML）に貼ります。</p>
            <table class="widefat striped" style="max-width:900px">
                <thead><tr><th style="width:170px">用途</th><th>ショートコード</th></tr></thead>
                <tbody>
                <tr><td><strong>標準</strong></td>
                    <td><code>[fudosan_sateisho]</code><br><span class="description">全項目・幅100%・枠なし。</span></td></tr>
                <tr><td><strong>コンパクト</strong><br><span class="description">サイドバー等</span></td>
                    <td><code>[fudosan_sateisho design="compact"]</code><br><span class="description">必須＋築年のみ・幅440pxのカード。</span></td></tr>
                <tr><td><strong>カード</strong></td>
                    <td><code>[fudosan_sateisho design="card"]</code><br><span class="description">全項目を枠＋影のカードで表示。</span></td></tr>
                </tbody>
            </table>
            <p class="description">属性：<code>button</code>（ボタン文言）が使えます。</p>

            <h3>受付後の動き</h3>
            <ol>
                <li>お客様に<strong>受付完了メール</strong>を自動返信（内容は「自動返信メール」タブで編集可）</li>
                <li><strong>通知先メール（担当者）</strong>に受付内容を通知（「基本設定」タブで指定）</li>
                <li>担当者が査定書を作成し、後日お客様のメール宛に送付</li>
            </ol>

            <h3>そのほか</h3>
            <ul style="list-style:disc;margin-left:20px">
                <li><strong>入力項目の増減・対象エリアの限定</strong> …「表示項目・対象エリア」タブ</li>
                <li><strong>メール文面（お客様向け）・テスト送信</strong> …「自動返信メール」タブ</li>
                <li><strong>ボタン色・見出し色</strong> …「デザイン」タブ</li>
                <li><strong>集まった受付データ</strong> … 左メニュー「査定書作成受付 → 受付一覧」（CSV書き出し／削除）</li>
            </ul>

            <h3 style="color:#b32d2e">法的な注意</h3>
            <p class="description">
                作成する査定書は<strong>「参考価格の情報提供」</strong>であり、不動産鑑定士による<strong>「鑑定評価」ではありません</strong>。
                フォーム・メールの免責文でその旨を明示しています。<strong>免責文は削除しないでください。</strong>公開前に弁護士等の確認を推奨します。
            </p>
            </div>

            <div id="fss-save"><?php submit_button(); ?></div>
        </form>
    </div>
    <script>
    (function(){
        var tabs = document.querySelectorAll('#fss-tabs .nav-tab');
        var panels = document.querySelectorAll('.fss-tabpanel');
        var save = document.getElementById('fss-save');
        tabs.forEach(function(t){
            t.addEventListener('click', function(e){
                e.preventDefault();
                tabs.forEach(function(x){ x.classList.remove('nav-tab-active'); });
                t.classList.add('nav-tab-active');
                var name = t.getAttribute('data-tab');
                panels.forEach(function(p){ p.style.display = (p.getAttribute('data-tab') === name) ? '' : 'none'; });
                if (save) save.style.display = (name === 'usage') ? 'none' : ''; // 使い方タブでは保存ボタンを隠す
            });
        });
    })();
    </script>
<?php }

function fss_leads_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'fudosan_sateisho_leads';
    $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 200");
    $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM $table");
    $export = wp_nonce_url(admin_url('admin-post.php?action=fss_export_leads'), 'fss_export_leads');
    echo '<div class="wrap"><h1>査定書作成受付 一覧</h1>';
    if (isset($_GET['deleted'])) echo '<div class="notice notice-success is-dismissible"><p>削除しました。</p></div>';
    $dberr = get_option('fss_last_db_error');
    if ($dberr) echo '<div class="notice notice-error"><p><strong>直近に保存エラーが発生しました：</strong> ' . esc_html($dberr) . '<br>最新版に更新すると自動修復を試みます。解消されない場合は、この赤いメッセージの文面を共有してください。</p></div>';
    echo '<p>受付件数：' . $total . ' 件（表示は最新200件）　<a class="button button-primary" href="' . esc_url($export) . '">CSVエクスポート（Excel）</a></p>';
    echo '<table class="widefat striped"><thead><tr>';
    echo '<th>受付日時</th><th>メール</th><th>種別</th><th>物件住所</th><th>利用目的</th><th>詳細</th><th>営業可</th><th>操作</th></tr></thead><tbody>';
    if ($rows) foreach ($rows as $r) {
        $plabel = isset($GLOBALS['FSS_PTYPE_LABEL'][$r->ptype]) ? $GLOBALS['FSS_PTYPE_LABEL'][$r->ptype] : $r->ptype;
        $det = isset($r->details) ? (string)$r->details : '';
        $del = wp_nonce_url(admin_url('admin-post.php?action=fss_delete_lead&id=' . $r->id), 'fss_delete_lead_' . $r->id);
        printf('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td style="white-space:pre-line;font-size:12px;line-height:1.5">%s</td><td>%s</td><td><a href="%s" onclick="return confirm(\'この受付を削除しますか？\')" style="color:#b32d2e">削除</a></td></tr>',
            esc_html($r->created_at), esc_html($r->email), esc_html($plabel),
            esc_html((isset($r->address) && $r->address !== '') ? $r->address : '-'),
            esc_html((isset($r->purpose) && $r->purpose !== '') ? $r->purpose : '-'),
            esc_html($det !== '' ? $det : '-'),
            $r->marketing_opt_in ? '○' : '', esc_url($del));
    } else echo '<tr><td colspan="8">まだありません</td></tr>';
    echo '</tbody></table></div>';
}

/* CSVエクスポート（Excel向けShift_JIS） */
/* =========================================================================
 * 濫用対策（メール爆撃の踏み台にされると送信ドメインのレピュテーションが死ぬ）
 * ※ nonce は未ログインだと全訪問者で同一値・最大24時間有効のため、ボット対策にならない。
 * ======================================================================= */

/** 送信元IP。CDN配下で全員が同一IP扱いになるのを避けるため標準ヘッダを優先する。
 *  偽装可能だが、本命の防御はメールアドレス単位の制限（爆撃したい宛先は固定のため）。 */
/* 文字数でDBカラム長に収める（超過するとinsertが失敗してリードが消える） */
function fss_trim_len($s, $max) {
    $s = (string)$s;
    if ($s === '') return $s;
    return function_exists('mb_substr') ? mb_substr($s, 0, $max) : substr($s, 0, $max);
}

function fss_client_ip() {
    foreach (array('HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR') as $h) {
        if (!empty($_SERVER[$h])) {
            $parts = explode(',', $_SERVER[$h]);
            $ip = trim($parts[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
}

function fss_rate_ok($bucket, $id, $limit, $window) {
    if ($id === '') return true;
    $k = 'fss_rl_' . $bucket . '_' . md5(strtolower($id));
    $n = (int) get_transient($k);
    if ($n >= $limit) return false;
    set_transient($k, $n + 1, $window);
    return true;
}

function fss_rl_limits() {
    return array(
        'ip_max'       => (int) apply_filters('fss_rl_ip_max', 5),                 // 同一IP: 1時間に5件
        'ip_window'    => (int) apply_filters('fss_rl_ip_window', HOUR_IN_SECONDS),
        'email_max'    => (int) apply_filters('fss_rl_email_max', 3),              // 同一メール: 24時間に3件
        'email_window' => (int) apply_filters('fss_rl_email_window', DAY_IN_SECONDS),
    );
}

/** ハニーポットと経過時間でボットを弾く。JSでfetch送信するため fss_elapsed は必ず入る。 */
function fss_bot_errors() {
    if (!empty($_POST['fss_website'])) return array('送信を受け付けられませんでした。');
    $elapsed = isset($_POST['fss_elapsed']) ? intval($_POST['fss_elapsed']) : 0;
    if ($elapsed < 3000) return array('入力が早すぎます。もう一度お試しください。');
    return array();
}

/**
 * CSVインジェクション対策。= + - @ 等で始まるセルは Excel が数式として実行してしまうため、
 * 先頭に ' を付けて無害な文字列にする（お客様の自由入力がそのままCSVに入るため必須）。
 * 数値（-5 等）はそのまま通す。
 */
function fss_csv_safe($s) {
    $s = (string)$s;
    if ($s === '' || is_numeric($s)) return $s;
    return (strpos("=+-@\t\r", $s[0]) !== false) ? "'" . $s : $s;
}

add_action('admin_post_fss_export_leads', 'fss_export_leads');
function fss_export_leads() {
    if (!current_user_can('manage_options')) wp_die('権限がありません');
    check_admin_referer('fss_export_leads');
    global $wpdb;
    $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fudosan_sateisho_leads ORDER BY id DESC", ARRAY_A);
    nocache_headers();
    header('Content-Type: text/csv; charset=Shift_JIS');
    header('Content-Disposition: attachment; filename="sateisho_uketsuke.csv"');
    $out = fopen('php://output', 'w');
    $head = array('ID','受付日時','メール','種別','物件住所','利用目的','詳細','営業同意');
    $cols = array('id','created_at','email','ptype','address','purpose','details','marketing_opt_in');
    $sjis = function ($s) { return mb_convert_encoding((string)$s, 'SJIS-win', 'UTF-8'); };
    fputcsv($out, array_map($sjis, $head));
    foreach ($rows as $r) {
        $line = array();
        foreach ($cols as $c) {
            $v = isset($r[$c]) ? $r[$c] : '';
            if ($c === 'ptype' && isset($GLOBALS['FSS_PTYPE_LABEL'][$v])) $v = $GLOBALS['FSS_PTYPE_LABEL'][$v];
            $line[] = $sjis(fss_csv_safe($v));
        }
        fputcsv($out, $line);
    }
    fclose($out);
    exit;
}

/* リード削除（個人情報の削除依頼対応） */
add_action('admin_post_fss_delete_lead', 'fss_delete_lead');
function fss_delete_lead() {
    if (!current_user_can('manage_options')) wp_die('権限がありません');
    $id = intval($_GET['id'] ?? 0);
    check_admin_referer('fss_delete_lead_' . $id);
    if ($id) {
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'fudosan_sateisho_leads', array('id' => $id));
    }
    wp_safe_redirect(admin_url('admin.php?page=fudosan-sateisho-leads&deleted=1'));
    exit;
}

/* =========================================================================
 * 4. 物件種別の対応表
 * ======================================================================= */
$GLOBALS['FSS_PTYPE_MAP']   = array('mansion' => '中古マンション等', 'house' => '宅地(土地と建物)', 'land' => '宅地(土地)');
$GLOBALS['FSS_PTYPE_LABEL'] = array('mansion' => '中古マンション', 'house' => '中古一戸建て（土地＋建物）', 'land' => '土地');
$GLOBALS['FSS_WAREKI']      = array('令和' => 2018, '平成' => 1988, '昭和' => 1925);







/* =========================================================================
 * 5. API取得（reinfolib）＋モックフォールバック
 * ======================================================================= */



/* 市区町村内の地区名（町名）を、取引件数の多い順に返す: array(array(name, count), ...) */



/* =========================================================================
 * 6. メール本文
 * ======================================================================= */
function fss_mail_body($ctx) {
    $tmpl = fss_opt('mail_body', '');
    if (trim($tmpl) === '') $tmpl = fss_default_mail_body();

    // 物件情報のまとまり（種別＋住所＋種別別の詳細）
    $pd = array();
    $pd[] = "■ 物件種別 : {$ctx['ptype_label']}";
    if (!empty($ctx['address'])) $pd[] = "■ 物件住所 : {$ctx['address']}";
    if (!empty($ctx['purpose'])) $pd[] = "■ 利用目的 : {$ctx['purpose']}";
    if (!empty($ctx['details']))  $pd[] = $ctx['details'];

    $repl = array(
        '{site_name}'        => fss_opt('site_name', '査定書作成受付'),
        '{property_details}' => implode("\n", $pd),
        '{ptype}'            => $ctx['ptype_label'],
        '{address}'          => isset($ctx['address']) ? $ctx['address'] : '',
        '{purpose}'          => isset($ctx['purpose']) ? $ctx['purpose'] : '',
        '{details}'          => isset($ctx['details']) ? $ctx['details'] : '',
        '{operator_name}'    => fss_opt('operator_name', ''),
        '{operator_contact}' => fss_opt('operator_contact', ''),
    );
    // 未設定の項目で「お問い合わせ: 」のようにラベルだけが残らないよう、その行ごと落とす
    if (trim($repl['{operator_contact}']) === '') $tmpl = preg_replace('/^.*\{operator_contact\}.*\R?/m', '', $tmpl);
    if (trim($repl['{operator_name}'])    === '') $tmpl = preg_replace('/^\h*\{operator_name\}\h*\R?/m', '', $tmpl);
    return fss_with_disclaimer(rtrim(strtr($tmpl, $repl)));
}

/**
 * 免責文は「鑑定評価ではない」ことを示す法的に必須の文面。
 * 本文テンプレートは管理画面で自由に編集できるため、テンプレート内に免責を置くと
 * 編集した瞬間に消えてしまう。よって★テンプレートの外で必ず連結する。
 * （既に免責を含むテンプレートには二重に付けない）
 */
function fss_legal_disclaimer() {
    return "───────────────────────────────\n"
        . "【ご注意】\n"
        . "・作成する査定書は『参考価格の情報提供』であり、\n"
        . "  不動産鑑定士による『鑑定評価』ではありません。\n"
        . "・実際の売却価格・成約価格を保証するものではありません。\n"
        . "・当社は宅地建物取引業者ではなく、売買の媒介・代理は行いません。\n"
        . "───────────────────────────────";
}

function fss_with_disclaimer($body) {
    // mbstring が無いサーバーでも動くよう strpos を使う（UTF-8同士の検索は strpos で正しく判定できる）
    if (strpos($body, '鑑定評価') === false) $body .= "\n\n" . fss_legal_disclaimer();
    return $body . "\n";
}

/* 件名テンプレ */
function fss_mail_subject() {
    $s = fss_opt('mail_subject', '');
    if (trim($s) === '') $s = '【{site_name}】査定書作成のお申し込みを受け付けました';
    return strtr($s, array('{site_name}' => fss_opt('site_name', '査定書作成受付')));
}

/* テストメール送信（迷惑メール判定・文面の確認用） */
add_action('admin_post_fss_test_mail', 'fss_test_mail');
function fss_test_mail() {
    if (!current_user_can('manage_options')) wp_die('権限がありません');
    check_admin_referer('fss_test_mail');
    $to = wp_get_current_user()->user_email;
    $ctx = array(
        'ptype_label' => 'マンション', 'address' => '東京都渋谷区〇〇1-2-3', 'purpose' => '相続した・相続する予定',
        'details' => "■ マンション名 : 〇〇マンション\n■ 専有面積（㎡） : 70\n■ 築年（西暦） : 2015\n■ 間取り : 2LDK",
    );
    $headers = array('Content-Type: text/plain; charset=UTF-8');
    $from = fss_opt('from_email'); $site = fss_opt('site_name', '査定書作成受付');
    if ($from) $headers[] = 'From: ' . $site . ' <' . $from . '>';
    $ok = wp_mail($to, '[テスト] ' . fss_mail_subject(), fss_mail_body($ctx), $headers);
    wp_safe_redirect(admin_url('admin.php?page=fudosan-sateisho&testmail=' . ($ok ? '1' : '0') . '&to=' . rawurlencode($to)));
    exit;
}

/* =========================================================================
 * 7. AJAX（admin-ajax 経由。REST無効化環境でも動く）
 * ======================================================================= */
/**
 * 新しいnonceを配る。
 * ページキャッシュが効いていると、HTMLに焼き込まれたnonceが古いまま配られ続け、
 * 24時間で失効した後は全員の送信が失敗する。JS側がこれを呼んで取り直せるようにする。
 * ※未ログイン用のnonceは元々ページを開けば誰でも取得できるため、公開しても強度は変わらない。
 */
add_action('wp_ajax_fudosan_sateisho_nonce', 'fss_ajax_nonce');
add_action('wp_ajax_nopriv_fudosan_sateisho_nonce', 'fss_ajax_nonce');
function fss_ajax_nonce() {
    if (!headers_sent()) {
        header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
        header('Pragma: no-cache');
    }
    wp_send_json(array('nonce' => wp_create_nonce('fudosan_sateisho')));
}

add_action('wp_ajax_fudosan_sateisho', 'fss_ajax');
add_action('wp_ajax_nopriv_fudosan_sateisho', 'fss_ajax');
function fss_ajax() {
    check_ajax_referer('fudosan_sateisho', 'nonce');

    // ボット・自動送信を先に弾く（DB・メールに一切触らせない）
    $bot = fss_bot_errors();
    if ($bot) wp_send_json(array('ok' => false, 'errors' => $bot));

    $lim = fss_rl_limits();

    $ptype   = sanitize_text_field($_POST['ptype'] ?? '');
    $address = sanitize_text_field($_POST['address'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');
    $note    = sanitize_textarea_field($_POST['note_text'] ?? '');
    $purpose = sanitize_text_field($_POST['purpose'] ?? '');
    if ($purpose !== '' && !in_array($purpose, fss_purposes(), true)) $purpose = '';
    $agree = !empty($_POST['agree']);
    $mkt   = !empty($_POST['marketing']);

    $errors = array();
    if (!$agree) $errors[] = '個人情報の取扱いへの同意が必要です。';
    if (!is_email($email)) $errors[] = 'メールアドレスの形式が正しくありません。';
    if ($address === '') $errors[] = '物件の住所を入力してください。';
    if (!isset($GLOBALS['FSS_PTYPE_MAP'][$ptype])) $errors[] = '物件種別を選択してください。';

    // 選択された種別のスキーマで各項目を取得・検証し、詳細テキストを組み立てる
    $schema = fss_property_fields();
    $detail_lines = array();
    if (isset($schema[$ptype])) {
        foreach ($schema[$ptype] as $fd) {
            $post_key = $ptype . '__' . $fd['key'];
            if ($fd['type'] === 'check') {
                $val = !empty($_POST[$post_key]) ? 'はい' : '';
            } elseif ($fd['type'] === 'textarea') {
                $val = sanitize_textarea_field($_POST[$post_key] ?? '');
            } else {
                $val = sanitize_text_field($_POST[$post_key] ?? '');
            }
            // 選択肢は選択肢外を無視
            if ($fd['type'] === 'select' && $val !== '' && !in_array($val, fss_opt_list($fd['opts']), true)) $val = '';
            if (!empty($fd['req']) && $val === '') {
                $errors[] = '「' . $fd['label'] . '」を入力してください。';
            }
            if ($val !== '') $detail_lines[] = '■ ' . $fd['label'] . ' : ' . $val;
        }
    }
    if ($errors) wp_send_json(array('ok' => false, 'errors' => $errors));

    // ★入力内容が正しいときだけ回数を数える。
    //   入力ミスでも数えると、間違えた正規のお客様が先にブロックされてしまう。
    if (!fss_rate_ok('ip', fss_client_ip(), $lim['ip_max'], $lim['ip_window'])) {
        wp_send_json(array('ok' => false, 'errors' => array(
            '送信が集中しています。しばらく時間をおいてからお試しください。')));
    }

    // ★本命の防御：同一アドレス宛の連続送信を止める（第三者のアドレスを入れての爆撃対策）
    if (!fss_rate_ok('email', $email, $lim['email_max'], $lim['email_window'])) {
        wp_send_json(array('ok' => false, 'errors' => array(
            'このメールアドレスでのお申し込みが続いています。24時間ほどおいてからお試しください。')));
    }

    $label = $GLOBALS['FSS_PTYPE_LABEL'][$ptype];
    if ($note !== '') $detail_lines[] = '■ 備考 : ' . $note;
    $details = implode("\n", $detail_lines);

    // リード保存（受付）
    global $wpdb;
    // 住所は必須の自由入力。255文字を超えるとinsertが失敗しリードが消えるため丸める
    $row = array(
        'created_at' => current_time('mysql'), 'email' => $email,
        'ptype' => $ptype, 'address' => fss_trim_len($address, 255), 'details' => $details,
        'purpose' => $purpose, 'marketing_opt_in' => $mkt ? 1 : 0,
    );
    $ins = $wpdb->insert($wpdb->prefix . 'fudosan_sateisho_leads', $row);
    if ($ins === false) {
        // 1回目失敗：不足カラムを補ってからもう一度だけ試す
        update_option('fss_last_db_error', $wpdb->last_error . ' @ ' . current_time('mysql'));
        fss_ensure_columns();
        $ins = $wpdb->insert($wpdb->prefix . 'fudosan_sateisho_leads', $row);
    }
    if ($ins === false) {
        // リトライも失敗：受付できていないので「完了」と偽らず、メールも送らずにエラーを返す
        update_option('fss_last_db_error', $wpdb->last_error . ' @ ' . current_time('mysql'));
        wp_send_json(array('ok' => false, 'errors' => array(
            '申し訳ありません。ただいま受付処理でエラーが発生しました。お手数ですが時間をおいて再度お試しください。',
        )));
    }
    delete_option('fss_last_db_error');   // 初回・リトライを問わず、保存に成功したらエラー記録を消す

    $ctx = array(
        'ptype_label' => $label, 'address' => $address, 'details' => $details, 'purpose' => $purpose,
    );

    // 受付完了メール（お客様へ）
    $site = fss_opt('site_name', '査定書作成受付');
    $from = fss_opt('from_email');
    $headers = array('Content-Type: text/plain; charset=UTF-8');
    if ($from) $headers[] = 'From: ' . $site . ' <' . $from . '>';
    $mail_ok = wp_mail($email, fss_mail_subject(), fss_mail_body($ctx), $headers);

    // 管理者通知（通知先メール。無ければ送信元→管理者アドレス）
    $notify = fss_opt('notify_email', $from ?: get_option('admin_email'));
    if ($notify) {
        wp_mail($notify, '【査定書作成】新しい受付が届きました', fss_admin_notify_body($ctx, $email), $headers);
    }

    wp_send_json(array(
        'ok' => true, 'mail_ok' => (bool)$mail_ok, 'email' => $email,
        'ptype_label' => $label, 'address' => $address, 'details' => $details, 'purpose' => $purpose,
    ));
}

/* =========================================================================
 * 8. ショートコード [fudosan_sateisho]
 * ======================================================================= */
add_shortcode('fudosan_sateisho', 'fss_shortcode');
/**
 * デザインパターン:
 *   [fudosan_sateisho]                  標準（全項目・幅100%・枠なし）
 *   [fudosan_sateisho design="compact"] コンパクト（必須＋築年のみ・カード・幅440px。メインビジュアル横向け）
 *   [fudosan_sateisho design="card"]    全項目をカード（枠＋影）で表示
 */
function fss_shortcode($atts = array()) {
    $a = shortcode_atts(array(
        'design' => 'default', 'button' => '',
    ), $atts, 'fudosan_sateisho');
    $design = in_array($a['design'], array('default', 'compact', 'card'), true) ? $a['design'] : 'default';
    $compact = ($design === 'compact');
    $btn     = $a['button'] !== '' ? sanitize_text_field($a['button']) : '査定書の作成を申し込む';

    // 装飾（設定画面のデザインタブ）
    $c_brand    = fss_opt('color_brand', '#1f6feb');
    $c_btn_text = fss_opt('color_btn_text', '#ffffff');
    $c_title    = fss_opt('color_title', '#1f6feb');
    $c_badge    = fss_opt('color_badge', '#ff5a36');
    $c_brand_rgb = fss_hex_to_rgb($c_brand);

    // compact は入力を最小限にする
    $show_purpose   = fss_show('purpose')   && !$compact;
    $show_marketing = fss_show('marketing') && !$compact;

    $nonce  = wp_create_nonce('fudosan_sateisho');

    $ajax   = admin_url('admin-ajax.php');
    $year   = intval(date('Y'));


    $privacy = fss_opt('privacy_url');
    $terms   = fss_opt('terms_url');


    $ptype_options = '<option value="">選択してください</option>'
        . '<option value="mansion">中古マンション</option>'
        . '<option value="house">中古一戸建て（土地＋建物）</option>'
        . '<option value="land">土地</option>';

    $agree_label = 'プライバシーポリシーおよび免責事項に同意します（必須）';
    if ($privacy || $terms) {
        $p = $privacy ? '<a href="' . esc_url($privacy) . '" target="_blank" rel="noopener">プライバシーポリシー</a>' : 'プライバシーポリシー';
        $t = $terms ? '<a href="' . esc_url($terms) . '" target="_blank" rel="noopener">免責事項</a>' : '免責事項';
        $agree_label = $p . 'および' . $t . 'に同意します（必須）';
    }

    $uid = 'fss-' . uniqid();

    ob_start(); ?>
<div class="fss-wrap fss-design-<?php echo esc_attr($design); ?>" id="<?php echo esc_attr($uid); ?>">
  <style>
    .fss-wrap{--fss-brand:<?php echo esc_attr($c_brand); ?>;--fss-brand-rgb:<?php echo esc_attr($c_brand_rgb); ?>;--fss-btn-text:<?php echo esc_attr($c_btn_text); ?>;--fss-title:<?php echo esc_attr($c_title); ?>;--fss-badge-bg:<?php echo esc_attr($c_badge); ?>;--fss-ink:#1a1f36;--fss-muted:#6b7280;--fss-line:#e5e7eb;width:100%;max-width:none;margin:0;color:var(--fss-ink);font-family:inherit;line-height:1.75;font-size:17px}
    /* 最後の要素（免責など）で切れると窮屈に見えるので、フォーム・結果とも下に余白を持たせる */
    .fss-card{background:transparent;border:0;border-radius:0;padding:0 0 28px}
    .fss-wrap{overflow-wrap:anywhere}   /* 長いメールアドレスや住所で横スクロールさせない */
    .fss-card > :last-child{margin-bottom:0}
    .fss-wrap label{display:block;font-weight:700;margin:18px 0 7px;font-size:17px;color:#374151;letter-spacing:.01em}
    /* 必須／任意バッジ */
    .fss-req,.fss-opt{font-size:11px;font-weight:700;border-radius:4px;padding:4px 7px;line-height:1;margin-left:8px;display:inline-flex;align-items:center;vertical-align:middle;letter-spacing:.02em;white-space:nowrap;flex:0 0 auto}
    .fss-req{background:var(--fss-badge-bg);color:#fff}
    .fss-opt{background:#eef1f5;color:#6b7280}
    .fss-req.fss-done{background:var(--fss-brand);color:#fff;border-radius:50%;width:20px;height:20px;padding:0;font-size:12px;justify-content:center}

    /* 引き継ぎ時の「続きはこちらから」バナー */

    /* セクション見出し（メリハリ） */
    .fss-section{display:flex;align-items:center;font-weight:800;font-size:21px;color:var(--fss-ink);margin:34px 0 10px;padding-left:12px;border-left:5px solid var(--fss-brand);line-height:1.45;letter-spacing:.01em}
    .fss-form > .fss-section:first-child{margin-top:0}

    .fss-wrap input,.fss-wrap select,.fss-wrap textarea{width:100%;padding:14px 15px;border:1px solid #cbd5e1;border-radius:9px;font-size:18px;background:#fff;box-sizing:border-box;transition:border-color .15s,box-shadow .15s}
    .fss-wrap input:focus,.fss-wrap select:focus,.fss-wrap textarea:focus{outline:none;border-color:var(--fss-brand);box-shadow:0 0 0 3px rgba(var(--fss-brand-rgb),.15)}
    .fss-row{display:flex;gap:12px}.fss-row>div{flex:1}
    /* 種別項目は2カラムでコンパクトに（textarea・チェックは全幅） */
    .fss-group{display:grid;grid-template-columns:1fr 1fr;gap:0 18px;align-items:start}
    .fss-field{min-width:0}
    .fss-field.fss-full{grid-column:1/-1}
    .fss-field > label:first-child{margin-top:16px}
    @media(max-width:560px){.fss-group{grid-template-columns:1fr}}
    .fss-hint{color:var(--fss-muted);font-size:14px;margin-top:5px;line-height:1.7}
    .fss-check{display:flex;gap:9px;align-items:flex-start;margin-top:14px}
    .fss-check input{width:auto;margin-top:6px;transform:scale(1.2)}.fss-check label{margin:0;font-weight:400;font-size:16px}
    .fss-wrap button{margin-top:24px;width:100%;background:var(--fss-brand);color:var(--fss-btn-text);border:0;border-radius:10px;padding:18px;font-size:20px;font-weight:700;cursor:pointer}
    .fss-wrap button:hover{filter:brightness(.93)}
    .fss-wrap button:disabled{opacity:.6;cursor:wait;filter:none}
    .fss-disc{background:#fff8e6;border:1px solid #f0e0a8;border-radius:10px;padding:15px 17px;font-size:14px;color:#6b5a12;margin-top:18px}
    /* ハニーポット：display:none だと一部のボットに読まれるため画面外へ逃がす */
    .fss-hp{position:absolute!important;left:-9999px!important;top:auto;width:1px;height:1px;overflow:hidden}
    .fss-privacy-note{background:#f6f8fa;border:1px solid var(--fss-line);border-radius:9px;padding:13px 15px;font-size:14px;color:#4b5563;line-height:1.75;margin-top:16px}
    .fss-operator{margin-top:18px;padding-top:16px;border-top:1px solid var(--fss-line);font-size:14px;color:#4b5563;line-height:1.9}
    .fss-operator-t{font-weight:700;color:var(--fss-ink);margin-bottom:4px;font-size:15px}
    .fss-operator span{display:inline-block;min-width:6.5em;color:var(--fss-muted)}
    .fss-err{background:#fdecea;border:1px solid #f5c6cb;color:#c0392b;padding:10px 12px;border-radius:9px;margin-bottom:10px;font-size:16px}
    .fss-price{font-size:34px;font-weight:800;color:var(--fss-brand);text-align:center;margin:8px 0}
    .fss-mid{text-align:center;color:var(--fss-muted);font-size:16px}
    .fss-spec{width:100%;border-collapse:collapse;margin:16px 0;font-size:17px}
    .fss-spec th,.fss-spec td{border-bottom:1px solid var(--fss-line);padding:12px 10px;text-align:left}
    .fss-spec th{color:var(--fss-muted);font-weight:600;width:38%}
    .fss-ok{color:#0a7d33;font-weight:600;font-size:16px;margin-top:16px}

    /* デザイン: compact / teaser（メインビジュアル横などに収める短い版） */
    .fss-design-compact,.fss-design-teaser{max-width:440px}
    .fss-design-compact .fss-card,.fss-design-teaser .fss-card{background:#fff;border:1px solid var(--fss-line);border-radius:14px;padding:20px 18px;box-shadow:0 8px 28px rgba(16,24,40,.10)}
    .fss-design-compact label,.fss-design-teaser label{font-size:16px;margin:12px 0 5px}
    .fss-design-compact input,.fss-design-compact select,.fss-design-compact textarea,.fss-design-teaser input,.fss-design-teaser select{padding:11px 12px;font-size:16px}
    .fss-design-compact button,.fss-design-teaser button{margin-top:16px;padding:14px;font-size:17px}
    .fss-design-compact .fss-form .fss-hint,.fss-design-teaser .fss-form .fss-hint{display:none}
    .fss-design-compact .fss-group,.fss-design-teaser .fss-group{grid-template-columns:1fr} /* 幅が狭いので1カラム */
    .fss-design-compact .fss-section{display:none} /* 短くするため見出しは省略 */
    .fss-design-compact .fss-check label{font-size:14px}
    .fss-design-compact .fss-disc{font-size:12px;padding:10px 12px;margin-top:12px}
    .fss-design-compact .fss-price{font-size:28px}
    .fss-design-compact .fss-spec{font-size:15px}
    .fss-design-compact .fss-spec th,.fss-design-compact .fss-spec td{padding:9px 8px}

    /* teaser: ヘッダー */
    /* ロゴあり: ロゴ左・テキスト右の横並び */

    /* teaser: ラベル横並び＋必須バッジ */

    /* 次に入力すべき欄をハイライト（全デザイン共通） */
    .fss-wrap select.fss-next,.fss-wrap input.fss-next{border-color:rgba(var(--fss-brand-rgb),.55);animation:fsPulse 1.5s ease-in-out infinite}
    @keyframes fsPulse{
      0%,100%{box-shadow:0 0 0 3px rgba(var(--fss-brand-rgb),.16)}
      50%{box-shadow:0 0 0 7px rgba(var(--fss-brand-rgb),.28)}
    }
    @media (prefers-reduced-motion:reduce){
      .fss-wrap select.fss-next,.fss-wrap input.fss-next{animation:none;box-shadow:0 0 0 3px rgba(var(--fss-brand-rgb),.20)}
    }

    /* デザイン: card（全項目を枠＋影のカードで） */
    .fss-design-card .fss-card{background:#fff;border:1px solid var(--fss-line);border-radius:14px;padding:24px 22px;box-shadow:0 4px 18px rgba(16,24,40,.06)}
  </style>

  <div class="fss-card fss-form-card">
    <div class="fss-errors"></div>
    <form class="fss-form">
      <?php /* ボット対策。人には見えず、自動入力ツールだけが埋める欄 */ ?>
      <div class="fss-hp" aria-hidden="true">
        <label for="<?php echo esc_attr($uid . '-website'); ?>">ウェブサイト（入力しないでください）</label>
        <input type="text" name="fss_website" id="<?php echo esc_attr($uid . '-website'); ?>" tabindex="-1" autocomplete="off">
      </div>
<?php if ($show_purpose): ?>
      <div class="fss-section">ご利用目的</div>
      <label>どのようなご事情ですか<span class="fss-opt">任意</span></label>
      <select name="purpose">
        <option value="">選択してください</option>
<?php foreach (fss_purposes() as $p): ?>
        <option value="<?php echo esc_attr($p); ?>"><?php echo esc_html($p); ?></option>
<?php endforeach; ?>
      </select>
<?php endif; ?>

      <div class="fss-section">物件の情報</div>
      <label>物件種別<span class="fss-req">必須</span></label>
      <select name="ptype" required><?php echo $ptype_options; ?></select>
      <div class="fss-hint">選ぶと、その種別の入力項目が表示されます</div>

      <label>物件の住所<span class="fss-req">必須</span></label>
      <input type="text" name="address" placeholder="例：東京都渋谷区〇〇1-2-3" required>
      <div class="fss-hint">丁目・番地までご記入ください（建物名・部屋番号は下の欄で結構です）</div>

<?php foreach (fss_property_fields() as $pt => $flds): ?>
      <div class="fss-group" data-ptype="<?php echo esc_attr($pt); ?>" style="display:none">
<?php foreach ($flds as $fd): $nm = $pt . '__' . $fd['key']; $full = ($fd['type'] === 'textarea'); ?>
        <div class="fss-field<?php echo $full ? ' fss-full' : ''; ?>">
<?php if ($fd['type'] === 'check'): ?>
          <div class="fss-check">
            <input type="checkbox" name="<?php echo esc_attr($nm); ?>" id="<?php echo esc_attr($uid . '-' . $nm); ?>" value="1">
            <label for="<?php echo esc_attr($uid . '-' . $nm); ?>"><?php echo esc_html($fd['chk']); ?></label>
          </div>
<?php else: ?>
          <label><?php echo esc_html($fd['label']); ?><?php echo $fd['req'] ? '<span class="fss-req">必須</span>' : '<span class="fss-opt">任意</span>'; ?></label>
<?php if ($fd['type'] === 'select'): ?>
          <select name="<?php echo esc_attr($nm); ?>" class="fss-typed" data-req="<?php echo $fd['req'] ? '1' : ''; ?>">
            <option value="">選択してください</option>
<?php foreach (fss_opt_list($fd['opts']) as $o): ?>
            <option value="<?php echo esc_attr($o); ?>"><?php echo esc_html($o); ?></option>
<?php endforeach; ?>
          </select>
<?php elseif ($fd['type'] === 'textarea'): ?>
          <textarea name="<?php echo esc_attr($nm); ?>" class="fss-typed" data-req="" rows="2" placeholder="<?php echo esc_attr(isset($fd['ph']) ? $fd['ph'] : ''); ?>"></textarea>
<?php else: ?>
          <input type="<?php echo $fd['type'] === 'number' ? 'number' : 'text'; ?>"<?php echo $fd['type'] === 'number' ? ' step="any" min="0"' : ''; ?> name="<?php echo esc_attr($nm); ?>" class="fss-typed" data-req="<?php echo $fd['req'] ? '1' : ''; ?>" placeholder="<?php echo esc_attr(isset($fd['ph']) ? $fd['ph'] : ''); ?>">
<?php endif; ?>
<?php endif; ?>
        </div>
<?php endforeach; ?>
      </div>
<?php endforeach; ?>

      <label>備考・その他<span class="fss-opt">任意</span></label>
      <textarea name="note_text" rows="2" placeholder="複数の接道がある場合など、補足があればご記入ください"></textarea>

      <div class="fss-section">ご連絡先</div>
      <label>結果をお届けするメールアドレス<span class="fss-req">必須</span></label>
      <input type="email" name="email" placeholder="you@example.com" required>

      <?php /* 個人情報の利用目的の明示（個情法21条）。同意を求める直前に必ず出す。
               プライバシーポリシーURLが未設定でも、最低限ここで目的が伝わるようにしておく */ ?>
      <div class="fss-privacy-note">
        <strong>個人情報の取り扱いについて</strong><br>
        ご入力いただいた内容は、<?php echo esc_html(fss_opt('operator_name', '当社')); ?>が<strong>査定書の作成とご送付、およびそれに関するご連絡</strong>のために利用します。
        ご本人の同意なく第三者に提供することはありません。削除をご希望の場合は下記の連絡先までお申し付けください。
      </div>

      <div class="fss-check">
        <input type="checkbox" name="agree" id="<?php echo esc_attr($uid . '-agree'); ?>" value="1" required>
        <label for="<?php echo esc_attr($uid . '-agree'); ?>"><?php echo $agree_label; ?></label>
      </div>
<?php if ($show_marketing): ?>
      <div class="fss-check">
        <input type="checkbox" name="marketing" id="<?php echo esc_attr($uid . '-mkt'); ?>" value="1">
        <label for="<?php echo esc_attr($uid . '-mkt'); ?>">売却に関するご提案・お役立ち情報のメール受け取りを希望します（任意）</label>
      </div>
<?php endif; ?>

      <button class="fss-submit" type="submit"><?php echo esc_html($btn); ?></button>
    </form>

    <div class="fss-disc">
      作成する査定書は<strong>参考価格の情報提供</strong>であり、不動産鑑定士による<strong>鑑定評価ではありません</strong>。実際の売却価格を保証するものではありません。<strong>当社は宅地建物取引業者ではなく、売買の媒介・代理は行いません。</strong>
    </div>
<?php
    /* 提供元の明示。お客様が「どこの誰に自宅の情報を渡すのか」を判断する材料であり、
       不動産では免許番号の有無が信頼性を大きく左右する。設定済みの項目だけを出す。 */
    $op_name = fss_opt('operator_name', '');
    $op_addr = fss_opt('operator_address', ''); $op_tel = fss_opt('operator_contact', '');
    if ($op_name || $op_addr || $op_tel):
?>
    <div class="fss-operator">
      <div class="fss-operator-t">このサービスの提供元</div>
<?php if ($op_name): ?>      <div><span>運営</span><?php echo esc_html($op_name); ?></div>
<?php endif; if ($op_addr): ?>      <div><span>所在地</span><?php echo esc_html($op_addr); ?></div>
<?php endif; if ($op_tel): ?>      <div><span>お問い合わせ</span><?php echo esc_html($op_tel); ?></div>
<?php endif; ?>
    </div>
<?php endif; ?>
  </div>

  <div class="fss-card fss-result" style="display:none"></div>
</div>

<script>
(function(){
  var AJAX = <?php echo wp_json_encode($ajax); ?>;
  var NONCE = <?php echo wp_json_encode($nonce); ?>;
  var LOADED_AT = Date.now();   // ページキャッシュがあってもJS側で計測すれば正しく効く
  var WRAP_ID = <?php echo wp_json_encode($uid); ?>;

  function init(){
  var wrap = document.getElementById(WRAP_ID);
  if (!wrap || wrap.getAttribute('data-fss-init')) return;
  wrap.setAttribute('data-fss-init', '1');
  var pref = wrap.querySelector('.fss-pref'), city = wrap.querySelector('.fss-city');
  var district = wrap.querySelector('.fss-district');
  var form = wrap.querySelector('.fss-form'), errBox = wrap.querySelector('.fss-errors');
  var formCard = wrap.querySelector('.fss-form-card'), resultCard = wrap.querySelector('.fss-result');
  var btn = wrap.querySelector('.fss-submit');
  var SUBMIT_LABEL = btn ? btn.textContent : '送信';
  var SENDING = false;   // 送信中フラグ（二重送信の防止。btn.disabled だけではEnter連打を防げない）

  var ptypeSel = wrap.querySelector('select[name="ptype"]');
  var cov = wrap.querySelector('.fss-coverage');
  var TYPE_COUNTS = null;
  var TYPE_LABELS = { mansion:'中古マンション', house:'一戸建て', land:'土地' };

  // （査定書受付では未使用。安全のため空実装で残す）
  function renderCoverage(){
    if (!cov) return;
    if (!TYPE_COUNTS) { cov.innerHTML = ''; return; }
    var parts = [];
    for (var k in TYPE_LABELS) parts.push(TYPE_LABELS[k] + ' ' + (TYPE_COUNTS[k] || 0) + '件');
    var html = 'この地域の取引事例：' + parts.join(' ／ ');
    var t = ptypeSel ? ptypeSel.value : '';
    if (t && (TYPE_COUNTS[t] || 0) < 5) {
      html += '<br><strong style="color:#c0392b">⚠ 選択中の種別は事例が少ないため、査定できない場合があります（その場合は個別査定をご案内します）。</strong>';
    }
    cov.innerHTML = html;
  }

  // 物件種別ごとの項目グループ
  var groups = wrap.querySelectorAll('.fss-group');

  // 直前の <label> 内の「必須」バッジ
  function badgeFor(el){
    var lbl = el.previousElementSibling;
    return (lbl && lbl.tagName === 'LABEL') ? lbl.querySelector('.fss-req') : null;
  }

  // 画面の並び順に：種別 → 住所 → 選択中の種別の必須項目 → メール
  function currentRequired(){
    var req = [];
    if (form.elements['ptype'])   req.push(form.elements['ptype']);
    if (form.elements['address']) req.push(form.elements['address']);
    var pt = ptypeSel ? ptypeSel.value : '';
    if (pt) {
      var g = wrap.querySelector('.fss-group[data-ptype="' + pt + '"]');
      if (g) Array.prototype.forEach.call(g.querySelectorAll('[data-req="1"]'), function(el){ req.push(el); });
    }
    if (form.elements['email'])   req.push(form.elements['email']);
    return req;
  }

  var resumeBox = null;

  function updateFormState(){
    Array.prototype.forEach.call(form.querySelectorAll('.fss-next'), function(e){ e.classList.remove('fss-next'); });
    var req = currentRequired(), firstEmpty = null, remaining = 0;
    req.forEach(function(el){
      var b = badgeFor(el);
      var filled = !!(el.value && String(el.value).trim() !== '');
      if (b) {
        if (filled) { b.classList.add('fss-done'); b.textContent = '✓'; }
        else { b.classList.remove('fss-done'); b.textContent = '必須'; }
      }
      if (!filled) { remaining++; if (!firstEmpty) firstEmpty = el; }
    });
    if (firstEmpty) firstEmpty.classList.add('fss-next');
    if (resumeBox) {
      if (remaining === 0) resumeBox.style.display = 'none';
      else { resumeBox.style.display = ''; resumeBox.querySelector('span').textContent = 'あと' + remaining + '項目で完了です'; }
    }
  }

  function insertResumeBanner(){
    var el = wrap.querySelector('.fss-next');
    if (!el) return;
    var anchor = el;
    while (anchor && anchor.parentNode !== form) anchor = anchor.parentNode;
    if (!anchor) return;
    var prev = anchor.previousElementSibling;
    if (prev && prev.tagName === 'LABEL') anchor = prev;
    resumeBox = document.createElement('div');
    resumeBox.className = 'fss-resume';
    resumeBox.innerHTML = '<b>↓ 続きはこちらから</b><span></span>';
    form.insertBefore(resumeBox, anchor);
    updateFormState();
  }

  // 種別を選ぶと、その種別の入力欄だけ表示
  function switchType(){
    var pt = ptypeSel ? ptypeSel.value : '';
    Array.prototype.forEach.call(groups, function(g){
      g.style.display = (g.getAttribute('data-ptype') === pt) ? '' : 'none';
    });
    updateFormState();
  }

  if (ptypeSel) ptypeSel.addEventListener('change', switchType);
  Array.prototype.forEach.call(form.querySelectorAll('.fss-typed, input[name="address"], input[name="email"]'), function(el){
    el.addEventListener('change', updateFormState);
    el.addEventListener('input', updateFormState);
  });

  switchType(); // 初期表示（種別グループ反映＋ガイド）
  /* ブラウザバック等でブラウザが種別を復元しても change は発火しないため、
     「中古マンションと表示されているのに入力欄が出ない」状態になる。読み込み時と
     bfcache 復帰時に自前で反映し直す。 */
  setTimeout(switchType, 0);
  setTimeout(switchType, 250);
  window.addEventListener('pageshow', function(e){ if (e.persisted) switchType(); });

  // 引き継ぎで来たときは、最初の未入力欄（＝光っている欄）まで自動スクロール
  function scrollToFirstEmpty(){
    var target = resumeBox || wrap.querySelector('.fss-next') || btn;
    if (!target) return;
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    // 市区町村の非同期読込でレイアウトが動くため、少し待ってから
    setTimeout(function(){
      target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
    }, 120);
  }


  function esc(s){ var d=document.createElement('div'); d.textContent=s==null?'':s; return d.innerHTML; }

  form.addEventListener('submit', function(e){
    e.preventDefault();

    if (SENDING) return;   // 送信中の再送信（連打・Enter連打）を止める
    SENDING = true;

    errBox.innerHTML = '';
    btn.disabled = true; btn.textContent = '送信中…';

    var fd = new FormData(form);
    fd.append('action', 'fudosan_sateisho');
    fd.append('nonce', NONCE);
    fd.append('fss_elapsed', String(Date.now() - LOADED_AT));   // 表示から送信までの経過ms（ボット判定）

    /* ページキャッシュで古いnonceが配られていると 403 になる。
       その場合だけ新しいnonceを取り直して1回だけ送り直す。 */
    function send(retried){
      fd.set('nonce', NONCE);
      return fetch(AJAX, { method:'POST', body: fd, credentials:'same-origin' })
        .then(function(r){
          if (r.status === 403 && !retried) {
            return fetch(AJAX + '?action=fudosan_sateisho_nonce', { credentials:'same-origin' })
              .then(function(x){ return x.json(); })
              .then(function(n){
                if (!n || !n.nonce) throw new Error('nonce');
                NONCE = n.nonce;
                return send(true);
              });
          }
          return r.json();
        });
    }

    send(false)
      .then(function(d){
        SENDING = false;
        btn.disabled = false; btn.textContent = SUBMIT_LABEL;
        /* ★応答が正しい形か必ず確かめる。
           admin-ajax は失敗時に -1 や 0 という「JSONとして解釈できてしまう値」を返す。
           素通しすると、1件も保存されていないのに「受け付けました」と表示してしまう。 */
        if (!d || typeof d !== 'object' || (d.ok !== true && !d.errors)) {
          throw new Error('bad-response');
        }
        if (d.errors) {
        errBox.innerHTML = d.errors.map(function(x){return '<div class="fss-err">'+esc(x)+'</div>';}).join('');
        errBox.scrollIntoView({ behavior:'smooth', block:'center' });   // 画面外だと「無反応」に見えて連打される
        return;
      }
        renderResult(d);
      })
      .catch(function(){
        SENDING = false;
        btn.disabled = false; btn.textContent = SUBMIT_LABEL;
        errBox.innerHTML = '<div class="fss-err">通信エラーが発生しました。時間をおいて再度お試しください。</div>';
      });
  });

  function renderResult(d){
    var rows = '<tr><th>物件種別</th><td>'+esc(d.ptype_label)+'</td></tr>'
      + (d.address ? '<tr><th>物件住所</th><td>'+esc(d.address)+'</td></tr>' : '')
      + (d.purpose ? '<tr><th>利用目的</th><td>'+esc(d.purpose)+'</td></tr>' : '');
    var det = '';
    if (d.details) {
      det = '<div class="fss-hint" style="white-space:pre-line;margin-top:10px">'+esc(d.details)+'</div>';
    }
    var mailLine = d.mail_ok
      ? '<p class="fss-ok">✓ '+esc(d.email)+' 宛に受付完了メールをお送りしました。</p>'
      : '<p class="fss-hint">受付は完了しています（確認メールの送信に失敗した可能性があります。担当より別途ご連絡します）。</p>';
    var html = '<h3 style="margin-top:0">査定書作成のお申し込みを受け付けました</h3>'
      + '<p>以下の内容で受け付けました。<strong>担当者が査定書を作成し、後日メールでお送りします。</strong></p>'
      + '<table class="fss-spec">'+rows+'</table>'
      + det
      + mailLine
      + '<div class="fss-disc">作成する査定書は<strong>参考価格の情報提供</strong>であり、不動産鑑定士による<strong>鑑定評価ではありません</strong>。実際の売却価格を保証するものではありません。<strong>当社は宅地建物取引業者ではなく、売買の媒介・代理は行いません。</strong></div>';
    resultCard.innerHTML = html;
    formCard.style.display = 'none';
    resultCard.style.display = 'block';
    resultCard.scrollIntoView({ behavior:'smooth', block:'start' });
  }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
</script>
<?php
    return ob_get_clean();
}
